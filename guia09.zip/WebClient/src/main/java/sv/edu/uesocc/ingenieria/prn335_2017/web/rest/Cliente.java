/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.uesocc.ingenieria.prn335_2017.web.rest;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import org.primefaces.event.SelectEvent;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.definiciones.Meta;

/**
 * Jersey REST client generated for REST resource:MetaResource [Meta]<br>
 * USAGE:
 * <pre>
 *        Client client = new Client();
 *        Object response = client.XXX(...);
 *        // do whatever with response
 *        client.close();
 * </pre>
 *
 * @author luis
 */
@Named("meta")
@ViewScoped
public class Cliente implements Serializable {

    Client cliente;
    WebTarget target;
    String BASE_URI = "http://localhost:8080/Web/webresources/";
    List<Meta> listaMeta;
    Meta metaEntity;
    boolean btnVisible = false;
//    String tar;
//    List<Meta> salida;

//    public Cliente() {
//        try {
//            cliente = (Client) ClientBuilder.newClient();
//            target = cliente.target("http://localhost:8080/Web/webresources/Meta/allRegistro");
//        } catch (Exception ex) {
//
//        }
//    }
    
    public void showMessage(String Mensaje) {
        FacesContext context = FacesContext.getCurrentInstance();
        context.addMessage(null, new FacesMessage(Mensaje));
    }
    
    public Cliente() {
        cliente = ClientBuilder.newClient();
    }

    @PostConstruct
    public void init() {
        this.metaEntity = new Meta();
        llenarTabla();

    }

    /**
     * Para llenar la tabla de la interfaz,metodos traidos del servidor
     */
    public void llenarTabla() {
        reset();
        try {
            listaMeta = cliente.target(BASE_URI).path("Meta/allRegistro").request(MediaType.APPLICATION_JSON).get(new GenericType<List<Meta>>() {
            });
        } catch (Exception ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, ex.getMessage(), ex);
        }
    }
    
    /**
     * Para crear un nuevo registro por medio de restful
     *
     * @return
     */
    public Meta crearRegistro() {
        if (metaEntity != null && metaEntity.getIdMeta() == null) {
            try {
                Meta salida = cliente.target(BASE_URI).path("Meta").request(MediaType.APPLICATION_JSON)
                        .post(Entity.entity(metaEntity, MediaType.APPLICATION_JSON), Meta.class);
                System.out.println("SE HA CREO CON EXITO!! SIRVE RESTFUL");
                showMessage("Se ha creado con exito");
                if (salida != null && salida.getIdMeta() != null) {
                    llenarTabla();
                    return salida;
                }
            } catch (Exception ex) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, ex.getMessage(), ex);
            }
        }
        return null;
    }

    /**
     * Para modificar un registro por medio de restful
     *
     * @return
     */
    public Meta editarRegistro() {
        if (metaEntity != null) {
            try {
                Meta salida = cliente.target(BASE_URI).path("Meta").request(MediaType.APPLICATION_JSON)
                        .put(Entity.entity(metaEntity, MediaType.APPLICATION_JSON), Meta.class);
                System.out.println("SE HA MODIFIO CON EXITO!! SIRVE RESTFUL");
                showMessage("Se ha modificado con exito");
                btnVisible = false;
                llenarTabla();
                return salida;
            } catch (Exception ex) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, ex.getMessage(), ex);
            }
        } else {
            System.out.println("DATOS VACIOS");
            btnVisible = false;
        }
        return null;
    }

    /**
     * Para eliminar un registro por medio de restful
     *
     * @return
     */
    public Meta eliminarRegistro() {
        if (metaEntity != null) {
            try {
                Meta salida = cliente.target(BASE_URI).path("Meta").path(metaEntity.getIdMeta().toString())
                        .request(MediaType.APPLICATION_JSON).delete(Meta.class);
                System.out.println("SE HA ELIMINO CON EXITO!! SIRVE RESTFUL");
                showMessage("Se ha eliminado con exito");
                btnVisible = false;
                llenarTabla();
                return salida;
            } catch (Exception ex) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, ex.getMessage(), ex);
            }
        } else {
            System.out.println("DATOS VACIOS");
            btnVisible = false;
        }
        return null;
    }

    public void reset() {
        metaEntity = new Meta();
    }

//    public List<Meta> findAll() {
//        salida = null;
//        try {
//            if (tar != null) {
//                if (tar.length() == 0) {
//                    salida = new ArrayList<>();
//                    System.out.println(tar + "vacio");
//                } else {
//
//                    List<Meta> encontrado;
//                    encontrado = target.request(MediaType.APPLICATION_JSON).get(new GenericType<List<Meta>>() {
//                    });
//                    salida = new ArrayList<>();
//                    for (Meta meta : encontrado) {
//
//                        if (meta.getNombre() != null && meta.getNombre().matches("(.*)" + tar + "(.*)")) {
//                            salida.add(meta);
//                        }
//                    }
////            salir();
//
//                }
//            }
//
//        } catch (Exception ex) {
//
//        } finally {
//            if (salida == null) {
//                salida = new ArrayList();
//            }
//        }
//        return salida;
//    }
//
//    public String getTar() {
//        return tar;
//    }
//
//    public void setTar(String tar) {
//        this.tar = tar;
//    }
        
    public void onRowSelect(SelectEvent event) {
        btnVisible = true;
    }

    public void btnCancelar() {
        metaEntity = new Meta();
        btnVisible = false;
    }

    public Client getCliente() {
        return cliente;
    }

    public void setCliente(Client cliente) {
        this.cliente = cliente;
    }

    public WebTarget getTarget() {
        return target;
    }

    public void setTarget(WebTarget target) {
        this.target = target;
    }

    public String getBASE_URI() {
        return BASE_URI;
    }

    public void setBASE_URI(String BASE_URI) {
        this.BASE_URI = BASE_URI;
    }

    public List<Meta> getListaMeta() {
        return listaMeta;
    }

    public void setListaMeta(List<Meta> listaMeta) {
        this.listaMeta = listaMeta;
    }

    public Meta getMetaEntity() {
        return metaEntity;
    }

    public void setMetaEntity(Meta metaEntity) {
        this.metaEntity = metaEntity;
    }

    public boolean isBtnVisible() {
        return btnVisible;
    }

    public void setBtnVisible(boolean btnVisible) {
        this.btnVisible = btnVisible;
    }

}

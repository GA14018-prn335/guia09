/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.uesocc.ingenieria.prn335_2017.web.rest;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.acceso.MetaFacadeLocal;
import sv.edu.uesocc.ingenieria.prn335_2017.datos.definiciones.Meta;

/**
 *
 * @author luis
 */
@Path("Meta") //Este path es utilizado para identificar la clase
public class MetaResource implements Serializable {

    @EJB
    private MetaFacadeLocal metaFacade;

    /**
     * Devuelve​ ​todos​ ​los​ ​registros​ ​existentes​
     *
     * @return
     */
    @GET
    @Path("/allRegistro") //Este path es utilizado para identificar el metodo
    @Produces({MediaType.APPLICATION_JSON})
    public List<Meta> findAll() {
        List salida = null;
        try {
            if (metaFacade != null) {
                salida = metaFacade.findAll();
            }
        } catch (Exception ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, ex.getMessage(), ex);
        } finally {
            if (salida == null) {
                salida = new ArrayList();
            }
        }
        return salida;
    }

    /**
     * Busca los registros en un rango, tomando por defecto inicio 0 y cantidad
     * 10
     *
     * @param first
     * @param pageSize
     * @return
     */
    @GET
    @Path("/rangeRegistro") //Este path es utilizado para identificar el metodo
    @Produces({MediaType.APPLICATION_JSON})
    public List<Meta> findRange(
            @DefaultValue("0") @QueryParam("first") int first,
            @DefaultValue("10") @QueryParam("pagesize") int pageSize
    ) {
        List salida = null;
        try {
            if (metaFacade != null) {
                salida = metaFacade.findRange(first, pageSize);
            }
        } catch (Exception ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, ex.getMessage(), ex);
        } finally {
            if (salida == null) {
                salida = new ArrayList();
            }
        }
        return salida;
    }

    /**
     * Busca un registro por su Identificador
     *
     * @param id
     * @return
     */
    @GET
    @Path("/byIdRegistro/{idmeta}") //Este path es utilizado para identificar el metodo
    @Produces({MediaType.APPLICATION_JSON})
    public Meta findById(
            @PathParam("idmeta") Integer id
    ) {
        try {
            if (metaFacade != null && id != null) {
                return metaFacade.find(id);
            }
        } catch (Exception ex) {
            
        }
        return new Meta();
    }
    
    
    
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Meta create(Meta reg){
        if(reg != null && reg.getIdMeta()== null){
            try {
                if (metaFacade != null) {
                    Meta m;
                    m = metaFacade.crear(reg);
                    if(m!=null){
                        return m;
                    }
                }
            } catch (Exception ex) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, ex.getMessage(), ex);
            }
        }
        return new Meta();
    }
    
    @PUT
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Meta edit(Meta reg){
        if(reg != null){
            try {
                if (metaFacade != null) {
                    Meta m;
                    m = metaFacade.editar(reg);
                    if(m!=null){
                        return m;
                    }
                }
            } catch (Exception ex) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, ex.getMessage(), ex);
            }
        }
        return new Meta();
    }
    
    @DELETE
    @Path("{id}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.APPLICATION_JSON)
    public Meta delete(@PathParam("id") int id){
        if(id > 0){
            try {
                if (metaFacade != null) {
                    Meta m;
                    m = metaFacade.remover(metaFacade.find(id));
                    if(m!=null){
                        return m;
                    }
                }
            } catch (Exception ex) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, ex.getMessage(), ex);
            }
        }
        return new Meta();
    }
     
       

}



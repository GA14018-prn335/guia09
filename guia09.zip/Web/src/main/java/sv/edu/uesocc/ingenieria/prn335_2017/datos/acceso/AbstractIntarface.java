/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sv.edu.uesocc.ingenieria.prn335_2017.datos.acceso;

import java.util.List;

/**
 *
 * @author luis
 */
public interface AbstractIntarface<T> {
    
    boolean create1(T Entity);
    
    void create(T Entity);
    
    T crear(T t);

    void edit(T Entity);
    
    T editar(T t);

    void remove(T Entity);
    
    T remover(T t);

    T find(Object id);

    List<T> findAll();

    List<T> findRange(int desde, int hasta);

    int count();
    
}
